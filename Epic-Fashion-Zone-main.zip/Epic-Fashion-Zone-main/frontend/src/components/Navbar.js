import { Link } from "react-router-dom";
import { ShoppingCart, Heart, Search, Menu, User, LogOut } from "lucide-react";
import { useState, useEffect } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export const Navbar = ({ cartCount = 0, wishlistCount = 0 }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    window.location.href = '/';
  };

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <Link to="/" className="flex items-center gap-3">
            <img 
              src="https://customer-assets.emergentagent.com/job_ethnic-treasures-12/artifacts/0qjx6l1g_Screenshot_20250308_115550_WhatsApp.jpg" 
              alt="Epic Fashion Zone Logo" 
              className="h-12 w-12 object-contain"
            />
            <h1 className="font-playfair text-3xl font-bold text-indigo-950">Epic Fashion Zone</h1>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="nav-link text-xs uppercase tracking-widest text-stone-600 hover:text-orange-600" data-testid="nav-home">
              Home
            </Link>
            <Link to="/products" className="nav-link text-xs uppercase tracking-widest text-stone-600 hover:text-orange-600" data-testid="nav-products">
              Shop
            </Link>
            <Link to="/products?category=Sarees" className="nav-link text-xs uppercase tracking-widest text-stone-600 hover:text-orange-600" data-testid="nav-sarees">
              Sarees
            </Link>
            <Link to="/products?category=Handicrafts" className="nav-link text-xs uppercase tracking-widest text-stone-600 hover:text-orange-600" data-testid="nav-handicrafts">
              Handicrafts
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <button className="p-2 hover:bg-orange-50 rounded-lg transition-colors" data-testid="search-button">
              <Search className="h-5 w-5 text-stone-600" />
            </button>
            <Link to="/wishlist" className="relative p-2 hover:bg-orange-50 rounded-lg transition-colors" data-testid="wishlist-link">
              <Heart className="h-5 w-5 text-stone-600" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-orange-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center" data-testid="wishlist-count">
                  {wishlistCount}
                </span>
              )}
            </Link>
            <Link to="/cart" className="relative p-2 hover:bg-orange-50 rounded-lg transition-colors" data-testid="cart-link">
              <ShoppingCart className="h-5 w-5 text-stone-600" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-orange-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center" data-testid="cart-count">
                  {cartCount}
                </span>
              )}
            </Link>

            {/* Login/User Menu */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 p-2 hover:bg-orange-50 rounded-lg transition-colors" data-testid="user-menu-button">
                    <User className="h-5 w-5 text-stone-600" />
                    <span className="hidden md:block text-sm font-medium text-stone-700">{user.name || user.email}</span>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {user.role === 'admin' && (
                    <DropdownMenuItem asChild>
                      <Link to="/admin/dashboard" data-testid="admin-dashboard-link">Admin Dashboard</Link>
                    </DropdownMenuItem>
                  )}
                  {user.role === 'customer' && (
                    <>
                      <DropdownMenuItem asChild>
                        <Link to="/account/orders" data-testid="my-orders-link">My Orders</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to="/account/addresses" data-testid="my-addresses-link">Saved Addresses</Link>
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="text-rose-600 cursor-pointer" data-testid="logout-button">
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link 
                to="/auth" 
                className="bg-indigo-950 hover:bg-indigo-900 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                data-testid="login-button"
              >
                Login
              </Link>
            )}

            <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)} data-testid="mobile-menu-button">
              <Menu className="h-6 w-6 text-stone-600" />
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-stone-100" data-testid="mobile-menu">
            <div className="flex flex-col space-y-3">
              <Link to="/" className="text-sm text-stone-600 hover:text-orange-600" data-testid="mobile-nav-home">Home</Link>
              <Link to="/products" className="text-sm text-stone-600 hover:text-orange-600" data-testid="mobile-nav-products">Shop</Link>
              <Link to="/products?category=Sarees" className="text-sm text-stone-600 hover:text-orange-600" data-testid="mobile-nav-sarees">Sarees</Link>
              <Link to="/products?category=Handicrafts" className="text-sm text-stone-600 hover:text-orange-600" data-testid="mobile-nav-handicrafts">Handicrafts</Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
